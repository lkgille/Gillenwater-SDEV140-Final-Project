"""
Final Project for SDEV140

"""

from breezypythongui import EasyFrame
import tkinter as tk
from tkinter import PhotoImage
from tkinter.font import Font


class SplashScreen(EasyFrame):
    # Displays splash screen
    def __init__(self):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)
        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        textLabel = self.addLabel(text = "Welcome to the music library. What would you like to do?", row = 1, column = 1, sticky = "NSEW")


        # Load image and associate it with the image label
        self.image = PhotoImage(file = "musicLogo5.png")
        imageLabel["image"] = self.image

        # Set font and color 
        font = Font(family = "Verdana", size = 14, slant = "roman", weight = "bold")
        textLabel["font"] = font
        textLabel["foreground"] = "SkyBlue2"

        self.addButton(text = "Manage songs", row = 2, column = 0, command = self.openSongWindow) #command = self.manageSongs)
        self.addButton(text = "Manage artists", row = 2, column = 1, command = self.openArtistWindow)
        self.addButton(text = "Click to exit", row = 2, column = 2, command = self.close) # resize ? / add padding

    def openArtistWindow(self):
        artistWindow(self)

    def openSongWindow(self):
        songWindow(self)

    def close(self):
        SplashScreen.destroy(self)
 

""" Artists Window """

class artistWindow(EasyFrame):
    # Opens the window to manage or view artists
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)
        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        # textLabel = self.addLabel(text = "Artist window", row = 1, column = 1, sticky = "NSEW")

        self.addButton(text = "Add", row = 4, column = 0, command = self.addArtist)
        self.addButton(text = "View artists", row = 4, column = 1, command = self.viewArtists)
        self.addButton(text = "Close", row = 4, column = 2, command = self.close)
        addArtistTitle = self.addLabel(text = "Add Artist", row = 0, column = 0)
        self.addLabel(text = "Artist name:", row = 2, column = 0)
        self.artist = self.addTextField(text = "", row = 2, column = 0)

        # Set font and color for Add Artist title
        font = Font(family = "Verdana", size = 14, slant = "roman", weight = "bold")
        addArtistTitle["font"] = font
        addArtistTitle["foreground"] = "SkyBlue2"

        f = open("artists.txt", 'w')
        
    def addArtist(self):
        f = open("artists.txt", 'a') # Allows for adding  favorite artists to the txt file
        # str(self.artist)
        f.write(self.artist)

    def viewArtists(self):
        print(artists.readlines())

    def close(self):
        artistWindow.destroy(self)
        SplashScreen.destroy(self)

class songWindow(EasyFrame):
    # Opens the window to manage or view songs
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)
        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        # textLabel = self.addLabel(text = "Song window", row = 1, column = 1, sticky = "NSEW")

        self.addButton(text = "Add", row = 4, column = 0, command = self.addSong)
        self.addButton(text = "View songs", row = 4, column = 1)
        self.addButton(text = "Close", row = 4, column = 2, command = self.close)
        addSongTitle = self.addLabel(text = "Add song", row = 0, column = 0)
        self.addLabel(text = "Song Title:", row = 2, column = 0)
        self.addTextField(text = "", row = 2, column = 0)
        self.addLabel(text = "Artist:", row = 3, column = 0)
        self.addTextField(text = "", row = 3, column = 0)
        # self.outputArea = self.addTextArea("", row = 4, column = 2, columnspan = 1, width = 20, height = 15)

        # Set font and color for Add Song title
        font = Font(family = "Verdana", size = 14, slant = "roman", weight = "bold")
        addSongTitle["font"] = font
        addSongTitle["foreground"] = "SkyBlue2"

        f = open("songs.txt", 'w')

    def addSong():
        f = open("songs.txt", 'a') # allows for adding a song to the text file

    def close(self):
        songWindow.destroy(self)

def main ():
    """ Instantiate and pop up the window. """
    SplashScreen().mainloop()

if __name__ == "__main__":
    main()
